'''
Copyright (C) 2018 Vitalii Shmorgun
3dvits@gmail.com

Created by Vitalii Shmorgun

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
    "name": "Panel of Actions List",
    "description": "Panel of Actions List",
    "author": "Vitalii Shmorhun",
    "version": (0, 2, 0),
    "blender": (2, 79, 0),
    "location": "View3D",
    "warning": "This addon is still in development.",
    "wiki_url": "",
    "category": "Object" }
       
import bpy      
from bpy.props import *
import bpy.utils.previews
import os

# global variables
custom_icons = None
sortRev = False
act = None
cu_check_list = [
'leftObjID',
'rightObjID',
'_leftModifer01',
'_rightModifer01',
'__leftModifer02',
'__rightModifer02',
'["RightForeArm"].constraints["IK"]',
'["LeftForeArm"].constraints["IK"]',
'["toolHolder.R"].constraints["rTool"]',
'["toolHolder.R"].constraints["lTool"]',
'["toolHolder.L"].constraints["Copy Location"]',
'["toolHolder.L"].constraints["Copy Rotation"]',
]
cIcons = [
	'arrow_up_left', 	'arrow_up', 	'arrow_up_right',
	'arrow_left',    	'dot',      	'arrow_right',
	'arrow_down_left',	'arrow_down',	'arrow_down_right', 'za',
	'turn_left_180',					'turn_right_180',
	'turn_left_90',						'turn_right_90',
	'edit_text',  'edit_text_selected'
	]

class ActionsPanel(bpy.types.Panel):
	bl_idname = "Actions_Panel"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = "Actions"
	bl_label = 'Action'

	def draw(self, context):
		global custom_icons
		global sortRev
		obj = bpy.context.active_object
		actions = bpy.data.actions
		selectedAct = ''
		selectedActGroup = ''
		if obj.animation_data:
			if obj.animation_data.action:
				selectedAct = obj.animation_data.action.name
				if 'group' in obj.animation_data.action:
					selectedActGroup = obj.animation_data.action['group']


		if not obj:
			return
		if not obj.animation_data:
			obj.animation_data_create()
		scene = context.scene
		row = self.layout.row()
		icon = "DOT"
		if 'loopAction' in scene:
			if scene['loopAction']:
				for func in bpy.app.handlers.frame_change_pre:
					if func.__name__ == 'loopAction':
						icon = 'FILE_TICK'
		row.operator("vit.loop_action",icon = icon, text = 'Loop Actions')
		
		row = self.layout.row()
		icon = "DOT"
		if 'jumpThroughActions' in scene:
			if scene['jumpThroughActions']:
				for func in bpy.app.handlers.frame_change_pre:
					if func.__name__ == 'actionsJumper':
						icon = 'FILE_TICK'
		row.operator("vit.actions_jumper",icon = icon, text = 'Actions Jumper')
		
		
		row = self.layout.row()
		icon = "DOT"
		if 'cu_actions_checking' in scene:
			if scene['cu_actions_checking']:
				icon = 'FILE_TICK'
		row.operator("vit.cu_togle_check",icon = icon, text = 'Toggle actions checking')
		

		hidden = []
		groups = ['Main Group']
		actionsInGroups = {}
		row = self.layout.row()
		row.alignment = 'RIGHT'
		if sortRev:
			azSort = row.operator("vit.set_action", icon = 'SORTALPHA', text = '').sort = -1
		else:
			azSort = row.operator("vit.set_action", icon_value=custom_icons['za'].icon_id, text = '').sort = -1
		hiddeAllGroup = row.operator("vit.set_action", icon = 'DOWNARROW_HLT', text = '',text_ctxt = "Enter a float")
		#~ hiddeAllGroup.alignment = 'RIGHT'
		hiddeAllGroup.allGroups = True
		hiddeAllGroup.groupHidde = False
		
		for a in actions:
			if 'hidden' in a:
				if a['hidden']:
					hidden.append(a)
					actionsInGroups[a.name] = 'Hidden'
					continue
			group = 'Main Group'
			if 'group' in a:
				if not a['group'] == '':
					group = a['group']
					if not a['group'] in groups:
						groups.append(a['group'])
			actionsInGroups[a.name] = group
		sortedGroup = [groups[0]]
		sortedGroup.extend(sorted(groups[1:]))#,reverse=sortRev))
		sortedGroup.append('Hidden')
		for g in (sortedGroup):
			groupHiddeIcon = 'RIGHTARROW'
			groupHidde = True
			if not g in scene:
				groupHiddeIcon = 'RIGHTARROW'
				groupHidde = False
			else:
				if scene[g]:
					groupHiddeIcon = 'DOWNARROW_HLT'
				else:
					groupHiddeIcon = 'RIGHTARROW'
				groupHidde = not scene[g]
			row = self.layout.row(align=True)
			if g != 'Main Group' and g != 'Hidden':
				if g == selectedActGroup:
					renameGroup = row.operator("vit.rename_actions_group", icon_value=custom_icons['edit_text_selected'].icon_id, text = '').group = g
				else:
					renameGroup = row.operator("vit.rename_actions_group", icon_value=custom_icons['edit_text'].icon_id, text = '').group = g
			row.label(g)

			hiddeGroupButton = row.operator("vit.set_action", icon = groupHiddeIcon, text = '',text_ctxt = "Enter a float")
			hiddeGroupButton.groupName = g
			hiddeGroupButton.groupHidde = groupHidde
			if g in scene:
				if scene[g] == False:
					continue
			for a in sorted(actionsInGroups,reverse=sortRev):
				if actionsInGroups[a] == g:
					mrow = self.layout.row()
					row = mrow.row(align=True)
					if 'description' in actions[a] :
						if actions[a]['description'] != '':
							renameButton = row.operator("vit.rename_action", icon = 'OUTLINER_DATA_FONT', text = '').name = a
						else:
							renameButton = row.operator("vit.rename_action", text = '' , icon_value=custom_icons['edit_text'].icon_id ).name = a
					else:
						renameButton = row.operator("vit.rename_action", text = '' , icon_value=custom_icons['edit_text'].icon_id ).name = a
					actButton = row.operator("vit.set_action", text = a)
					actButton.name = a
					
					hi = -1
					ic = 'RESTRICT_VIEW_ON'
					if g == 'Hidden':
						hi = 1
						ic = 'RESTRICT_VIEW_OFF'
					hiddeButton = row.operator("vit.set_action", text = '', icon = ic)
					hiddeButton.name = a
					hiddeButton.hidde = hi
					marker = 'dot'
					if 'marker' in actions[a]:
						if actions[a]['marker'] in custom_icons:
							marker = actions[a]['marker']
					mrow.operator("vit.set_marker_popup", text = '', icon_value=custom_icons[marker].icon_id).name = a
					row = self.layout.row()
					if obj.animation_data.action:
						if obj.animation_data.action.name == a:
							if "description" in actions[a]:
								row.prop(actions[a], '["description"]', text="")
class SetAction(bpy.types.Operator):
	bl_idname = "vit.set_action"
	bl_label = "Set action"
	name = bpy.props.StringProperty()
	hidde = bpy.props.IntProperty()
	groupName = bpy.props.StringProperty()
	groupHidde = bpy.props.BoolProperty()
	sort = bpy.props.IntProperty()
	allGroups = bpy.props.BoolProperty()
	def execute(self, contex):
		scene = contex.scene

		obj = bpy.context.active_object
		actions = bpy.data.actions
		global sortRev
		if self.sort == -1:
			sortRev = not sortRev
		else:
			if self.allGroups:
				groups = []
				for a in actions:
					if 'group' in a:
						if not a['group'] in groups:
							groups.append(a['group'])
				for g in groups:
					bpy.context.scene[g] = self.groupHidde
				bpy.context.scene['Hidden'] = self.groupHidde
				bpy.context.scene['Main Group'] = self.groupHidde
			if self.groupName != '':
				bpy.context.scene[self.groupName] = self.groupHidde
			elif self.name in actions:
				if self.hidde == -1:
					actions[self.name]['hidden'] = True
				elif self.hidde == 1:
					actions[self.name]['hidden'] = False
				else:
					obj.animation_data.action = actions[self.name]
					#*************************
					if 'cu_actions_checking' in scene:
						if scene['cu_actions_checking']:
							check_list = []
							for c in cu_check_list:
								check_list.append(False)
								for f in obj.animation_data.action.fcurves:
									if c in f.data_path:
										check_list[-1] = True
							for i in range(len(check_list)):
								if not check_list[i]:
									print(cu_check_list[i])
	
						
					bpy.context.scene.frame_end = obj.animation_data.action.frame_range[1]-1
					bpy.context.scene.frame_start = obj.animation_data.action.frame_range[0]
					#bpy.context.scene.frame_current  = obj.animation_data.action.frame_range[0]
				try:
					actions[self.name]["description"]
				except:
					actions[self.name]["description"] = ''
		self.sort = 0
		self.hidde = 0
		self.groupName = ''
		self.allGroups = False
		return {'FINISHED'}

class ActionsGroupsMenu(bpy.types.Menu):
	bl_label = "Actions Groups Menu"
	bl_idname = "actions_groups_menu"
	action = bpy.props.StringProperty() 
	def draw(self, context):
		layout = self.layout
		groups = []
		global act
		for a in bpy.data.actions:
			if 'group' in a:
				if not a['group'] in groups:
					groups.append(a['group'])
		for g in sorted(groups):
			gr = layout.operator("vit.set_action_group", text=g)
			gr.name = act
			gr.group = g

class RenameActionsGroup(bpy.types.Operator):
	bl_idname = "vit.rename_actions_group"
	bl_label = "Rename Actions Group"
 
	group = StringProperty(name="String Value")
	groupName = ''
	def execute(self, context):
		for a in bpy.data.actions:
			print(a.name, ' groupName = ', self.groupName)
			if 'group' in a:
				print('_______',self.group)
				if a['group'] == self.groupName:
					a['group'] = self.group
					if self.groupName in bpy.context.scene:
						bpy.context.scene[a['group']] = bpy.context.scene[self.groupName]

		return {'FINISHED'}
 
	def invoke(self, context, event):
		self.groupName = self.group
		return context.window_manager.invoke_props_dialog(self)


class RenameAction(bpy.types.Operator):
	bl_idname = "vit.rename_action"
	bl_label = "Change action name and group"
	name = bpy.props.StringProperty()

	def execute(self, context):
		return {'FINISHED'}
	def invoke(self, context, event):
		action = bpy.data.actions[self.name]
		if not 'group' in action:
			action['group'] = ''
		if not 'description' in action:
			action['description'] = ''
		return context.window_manager.invoke_props_dialog(self)
		
	def draw(self, context):
		layout = self.layout
		split = layout.split(percentage=0.2)
		row = split.label(text = 'name:')
		row = split.row(align = True)
		action = bpy.data.actions[self.name]
		row.prop(action, 'name', text="")
		split = layout.split(percentage=0.2)
		row = split.label(text = 'group:')
		row = split.row(align = True)
		action = bpy.data.actions[self.name]

		row.prop(action, '["group"]', text="")
		global act
		act = self.name
		menu = row.menu("actions_groups_menu",text='', icon = 'DOWNARROW_HLT')
		split = layout.split(percentage=0.2)
		row = split.label(text = 'desc:')
		row = split.row(align = True)
		action = bpy.data.actions[self.name]
		row.prop(action, '["description"]', text="")

class SetActionGroup(bpy.types.Operator):
	bl_idname = "vit.set_action_group"
	bl_label = "Set Action Group"
	name = bpy.props.StringProperty()
	group = bpy.props.StringProperty()
	def execute(self, context):
		if self.name in bpy.data.actions: 
			bpy.data.actions[self.name]['group'] = self.group
		return {'FINISHED'}

class SetActionMarker(bpy.types.Operator):
	bl_idname = "vit.set_action_marker"
	bl_label = "Set Action Marker"
	name = bpy.props.StringProperty()
	marker = bpy.props.StringProperty()
	def execute(self, context):
		if self.name in bpy.data.actions: 
			bpy.data.actions[self.name]['marker'] = self.marker
		return {'FINISHED'}

class ActionMarkerPopup(bpy.types.Operator):
	bl_idname = "vit.set_marker_popup"
	bl_label = "Set Action Marker Popup"
	name = bpy.props.StringProperty()
	def execute(self, context):
		return {'FINISHED'}
	def invoke(self, context, event):
		return context.window_manager.invoke_popup(self)
	def draw(self, context):
		global cIcons 
		p = self.layout.column()
		col = p.column(align=True)
		n = 0
		for c in range(3):
			row = col.row(align=True)
			for r in range(3):
				btn = row.operator("vit.set_action_marker", icon_value=custom_icons[cIcons[n]].icon_id, text = '')
				btn.name = self.name
				btn.marker = cIcons[n]
				n += 1
		row = col.row(align=True)
		for n in range(4):
			btn = row.operator("vit.set_action_marker", icon_value=custom_icons[cIcons[n+10]].icon_id, text = '')
			btn.name = self.name
			btn.marker = cIcons[n+10]
	

class ToggleActionsCheck(bpy.types.Operator):
	bl_idname = "vit.cu_togle_check"
	bl_label = "Toggle actions checking"
	name = bpy.props.StringProperty()
	def execute(self, context):
		scene = context.scene
		if 'cu_actions_checking' not in scene:
			scene['cu_actions_checking'] = True
		else:
			scene['cu_actions_checking'] = not scene['cu_actions_checking']

		return {'FINISHED'}
		


class ActionLoop(bpy.types.Operator):
	bl_idname = "vit.loop_action"
	bl_label = "Loop Action"
	name = bpy.props.StringProperty()
	def execute(self, context):
		scene = context.scene
		if 'loopAction' not in scene:
			scene['loopAction'] = True
		else:
			if scene['loopAction']:
				scene['loopAction'] = False
			else:
				scene['loopAction'] = True
		b = True
		handler_list = bpy.app.handlers.frame_change_pre  
		fin = len(handler_list)
		for idx, func in enumerate(reversed(handler_list)):
			if func.__name__ == 'loopAction':
				handler_list.pop(fin-1-idx)
				b = False
		bpy.app.handlers.frame_change_pre.append(loopAction)
		if b:
			scene['loopAction'] = True
		return {'FINISHED'}
		
def loopAction(scene):
	if scene['loopAction']:
		if scene.frame_current > scene.frame_end:
			scene.frame_current = scene.frame_start
		elif scene.frame_current < scene.frame_start:
			scene.frame_current = scene.frame_end



class ActionsJumper(bpy.types.Operator):
	bl_idname = "vit.actions_jumper"
	bl_label = "Actions Jumper"
	name = bpy.props.StringProperty()
	def execute(self, context):
		scene = context.scene
		obj = bpy.context.selected_objects[0]
		if 'jumpThroughActions' not in scene:
			scene['jumpThroughActions'] = True
		else:
			scene['jumpThroughActions'] = not scene['jumpThroughActions']
		print(scene['jumpThroughActions'])
		b = True
		handler_list = bpy.app.handlers.frame_change_pre  
		fin = len(handler_list)
		for idx, func in enumerate(reversed(handler_list)):
			if func.__name__ == 'actionsJumper':
				handler_list.pop(fin - 1 - idx)
				b = False
		bpy.app.handlers.frame_change_pre.append(actionsJumper)
		if b:
			scene['jumpThroughActions'] = True
			
		return {'FINISHED'}
		

def nextAction(obj):
	actions = bpy.data.actions
	current = obj.animation_data.action
	next = 0
	num = len(actions.items())
	for i in range(num):
		a = actions[i]
		if current.name == a.name:
			if i < (num-1):
				next = i + 1
	print(next)
	obj.animation_data.action = actions[next]
	return(actions[next])

def actionsJumper(scene):
	if scene['jumpThroughActions']:
		if scene.frame_current == scene.frame_end:
			obj = bpy.context.selected_objects[0]
			scene.frame_current = scene.frame_start
			nextAction(obj)
			if obj.animation_data:
				bpy.context.scene.frame_end = obj.animation_data.action.frame_range[1]-1

def register():
	global custom_icons
	global cIcons
	custom_icons = bpy.utils.previews.new()
	icons_dir = os.path.join(os.path.dirname(__file__), "icons")
	for ico in cIcons:
		custom_icons.load(ico, os.path.join(icons_dir, str(ico+'.png')), 'IMAGE')
	bpy.utils.register_module(__name__)

def unregister():
	global custom_icons
	bpy.utils.previews.remove(custom_icons)
	bpy.utils.unregister_module(__name__)
