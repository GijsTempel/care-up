﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Send and read the Savegame1.txt file.")]
	public class LAPS_Example2 : LAPS_Action
	{
		// EXECUTION
		public override void OnEnter()
		{
			// Read a saveGameFile
			TextAsset bindata = Resources.Load("Savegames files/Savegame1") as TextAsset; // CAUTION your resource must have a .txt extension
			string savegame = bindata.text;
			savegame = LoginPro_Security.To64String(savegame); 	// Encode it in base64 string to make sure no character will be replaced
			
			// Information to send to the server
			string[] datas = new string[2];
			datas[0] = "Savegame1";
			datas[1] = savegame;
			
			// Send datas on the server, then call 'handleSavefileError' if the message of the server contains "ERROR". 'handleSavefileSuccess' if not
			laps.ExecuteOnServer("Savefile", success, fail, datas);
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			laps.log (serverDatas[0]);

			// Here, if you build the solution make sure you can reach the folder you specify here (depending on where the build is located)
			string mySaveGamePath = Application.dataPath+"/Savegame1_Received.txt";
			#if UNITY_EDITOR
			mySaveGamePath = Application.dataPath+"/LoginAccountProSecure/Framework/Resources/Savegames files/Savegame1_Received.txt";
			#endif
			
			#if UNITY_WEBPLAYER
			Debug.Log(mySaveGamePath);
			alertField.text = "If you are on webplayer you can't send/receive files, switch plateform in your build settings.";
			#else
			string fileReceived = LoginPro_Security.From64String(serverDatas[1]);  // Decode it from base64 string (we sent it like that)
            LoginPro_Security.writeTextInFile(mySaveGamePath, fileReceived);
			#endif
			Fsm.Event(successEvent);									// Go to Success
		}
	}
}
