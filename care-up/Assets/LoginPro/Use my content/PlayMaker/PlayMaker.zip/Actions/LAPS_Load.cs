﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Get information from the server and save it in a variable.")]
	public class LAPS_Load : LAPS_Action
	{
		// DATAS SENT
		[Tooltip("Get the variable of the current username (of the player's account)?")]
		public FsmBool IsPersonnal = true;
		
		[RequiredField]
		public FsmString[] Keys;

		// DATAS SENT
		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmString variable;
		
		// EXECUTION
		public override void OnEnter()
		{
			string[] datas = new string[2];
			datas[0] = IsPersonnal.Value ? "True" : "False";
			//datas[1] = ServerMakerSerializer.ConcatKeys(Keys);

			laps.ExecuteOnServer("Load", success, fail, datas);
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			string data_type = serverDatas[0];	// Save the type of the data
			Debug.Log (data_type);
			variable.Value = serverDatas[1];	// Save the data received
			Fsm.Event(successEvent);			// Go to Success
		}
	}
}