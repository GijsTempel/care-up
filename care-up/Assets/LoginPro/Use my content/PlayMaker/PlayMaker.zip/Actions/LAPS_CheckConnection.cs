﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Send user data for registration.")]
	public class LAPS_CheckConnection : LAPS_Action
	{
		// USER SESSION DATAS
		private FsmBool UserSession_IsConnected;
		private FsmString UserSession_SessionID;
		private FsmString UserSession_Username;
		private FsmString UserSession_Password;
		
		// EXECUTION
		public override void OnEnter()
		{
			if(LoginPro.Session == null || !LoginPro.Session.LoggedIn)	// If we are not logged in -> fail
				Fsm.Event(failEvent);
			else 						// Otherwise -> success
				Fsm.Event(successEvent);
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			// Otherwise -> save datas in global variables, success
			UserSession_IsConnected = FsmVariables.GlobalVariables.GetFsmBool("UserSession_IsConnected");
			UserSession_SessionID = FsmVariables.GlobalVariables.GetFsmString("UserSession_SessionID");
			UserSession_Username = FsmVariables.GlobalVariables.GetFsmString("UserSession_Username");
			UserSession_Password = FsmVariables.GlobalVariables.GetFsmString("UserSession_Password");
			
			// Save user session datas
			UserSession_IsConnected.Value = true;
			UserSession_SessionID.Value = LoginPro.Session.Session_id;
			UserSession_Username.Value = LoginPro.Session.Username;
			UserSession_Password.Value = LoginPro.Session.Password;
			
			// Success
			Fsm.Event(successEvent);
		}
	}
}
