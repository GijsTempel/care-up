// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Send user data to reinitialize password.")]
	public class LAPS_Forgot : LAPS_Action
	{
		// DATAS SENT
		[RequiredField]
		public FsmString mail;
		private bool CheckDatas()
		{
			if(!mail.Value.Contains("@")) { laps.log("Your email address is not valid."); return false; }
			return true;
		}
		
		// EXECUTION
		public override void OnEnter()
		{
			if(CheckDatas()) // If datas are correct
			{
				string[] datas = new string[1];
				datas[0] = mail.Value;
				
				laps.ExecuteOnServer("Forgot", success, fail, datas);
			}
			else { fail("Reintialization failed."); } // Raise the fail event if datas are not correct
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			laps.log(serverDatas[0]);			// Show the message on UI (not an error)
			Fsm.Event(successEvent);			// Go to Success
		}
	}
}