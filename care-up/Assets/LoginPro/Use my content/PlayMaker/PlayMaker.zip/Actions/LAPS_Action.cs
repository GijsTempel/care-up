// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	public abstract class LAPS_Action : FsmStateAction
	{
		// DATAS
		[RequiredField]
		[Tooltip("The owner.")]
		public FsmOwnerDefault owner;

		private GameObject _ownerObject = null;
		protected GameObject ownerObject
		{
			get
			{
				if(_ownerObject==null)
					_ownerObject = Fsm.GetOwnerDefaultTarget(owner);
				return _ownerObject;
			}
		}

		private PlayMakerFSM _ownerFSM = null;
		protected PlayMakerFSM ownerFSM
		{
			get
			{
				if(_ownerFSM==null)
					_ownerFSM = ownerObject.GetComponent<PlayMakerFSM>();
				return _ownerFSM;
			}
		}
		
		private LAPS _laps = null;
		protected LAPS laps
		{
			get
			{
				if(_laps==null)
					_laps = ownerObject.GetComponent<LAPS>();
				return _laps;
			}
		}

		// EVENTS
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public override void Reset()
		{
			successEvent = null;
			failEvent = null;
		}
		
		public abstract void success(string[] serverDatas);
		
		public void fail(string errorMessage)
		{
			Fsm.Event(failEvent);
		}
	}
}