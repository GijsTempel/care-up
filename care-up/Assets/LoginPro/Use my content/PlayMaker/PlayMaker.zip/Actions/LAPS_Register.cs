// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Send user data for registration.")]
	public class LAPS_Register : LAPS_Action
	{
		// DATAS SENT
		[RequiredField]
		public FsmString mail;
		[RequiredField]
		public FsmString username;
		[RequiredField]
		public FsmString password;
		[RequiredField]
		public FsmString confirmPassword;
		private bool CheckDatas()
		{
			if(!mail.Value.Contains("@")) { laps.log("Your email address is not valid."); return false; }
			if(username.Value.Length < 3) { laps.log("Your username must be 3 characters at least."); return false; }
			if(password.Value.Length < 3) { laps.log("Your password must be 3 characters at least."); return false; }
			if(!password.Value.Equals(confirmPassword.Value)) { laps.log("Your password confirmation do not match."); return false; }
			return true;
		}
		
		// EXECUTION
		public override void OnEnter()
		{
			if(CheckDatas()) // If datas are correct
			{
				string[] datas = new string[3];
				datas[0] = mail.Value;
				datas[1] = username.Value;
				datas[2] = LoginPro_Security.hash(password.Value);
				
				laps.ExecuteOnServer("Register", success, fail, datas);
			}
			else { fail("Registration failed."); } // Raise the fail event if datas are not correct
		}
		
		// SUCCESS
		public override void success(string[] serverDatas)
		{
			laps.log(serverDatas[0]);						// Show the message on UI (not an error)
			PlayerPrefs.SetString("username",username.Value);		// Save username in the player's prefs
			PlayerPrefs.SetString("password",password.Value);		// Save password in the player's prefs
			Fsm.Event(successEvent);								// Go to Success
		}
	}
}