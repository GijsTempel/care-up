﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Events")]
	[Tooltip("Fire a specified event.")]
	public class FireEvent : FsmStateAction
	{
		// DATAS SENT
		[RequiredField]
		public FsmEvent eventToFire;
		
		// EXECUTION
		public override void OnEnter()
		{
			Fsm.Event(eventToFire);
		}
	}
}