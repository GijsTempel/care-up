﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("LAPS")]
	[Tooltip("Disconnect the user.")]
	public class LAPS_Disconnect : FsmStateAction
	{
		// EXECUTION
		public override void OnEnter()
		{
            LoginPro.Session.ClearSession();
		}
	}
}