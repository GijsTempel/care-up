﻿// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("UI")]
	[Tooltip("LAPS: Set the text of an UI component.")]
	public class SetUiLabel : FsmStateAction
	{
		// DATAS
		[RequiredField]
		[Tooltip("Drag the UI text gameObject here.")]
		public Text textObject;
		
		[RequiredField]
		[Tooltip("The variable to show in the UI text.")]
		public FsmString variable;
		
		public override void OnEnter()
		{
			textObject.text = variable.Value;
		}
	}
}