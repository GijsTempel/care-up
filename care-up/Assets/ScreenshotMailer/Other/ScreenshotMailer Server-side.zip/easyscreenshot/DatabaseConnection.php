<?php
require_once 'medoo.min.php';

$database = new medoo([
	'database_type' => 'mysql',
	'database_name' => 'name',
	'server' => "server",
	'username' => "username" ,
	'password' => "password" ,
]);

?>