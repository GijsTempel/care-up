
<?php

require("DatabaseConnection.php");

require("class.phpmailer.php");

$image = $_POST["image"];
$emailAddress = $_POST["emailaddress"];
$firstTime = false;

if (!$database->has("accounts",  array(
		"hex_identifier" => $emailAddress
	)
)){
	$firstTime = true;
	$database->insert('accounts',  array(
		'email' => $emailAddress
	));
}

$accountData = $database->select("accounts",array(
		"activated",
		"banned_timestamp",
		"id"
		),array(
		"email" => $emailAddress
	))[0];
	
$activated = $accountData['activated'];
$bannedTimestamp = $accountData['banned_timestamp'];
$emailId = $accountData['id'];
$currentTimeStamp = date_timestamp_get(date_create());

	if(!$activated && $firstTime){
		// Send activation email
		prepareActivationMail();
	} else if (!$activated && !$firstTime){
		// Don't send more emails untill activated
		echo "Sending screenshot failed. Make sure your mail address has been verified through the verification email!";
		return;
	} else if($activated){
		if($bannedTimestamp != "0"){
			// Check if user is banned
			if(($currentTimeStamp - $bannedTimestamp) > 300) {
				// Not banned anymore
				$database->update('accounts', array(
					'banned_timestamp' => "0"
				),array(
					'id' => $emailId
				));
			} else{
				// Still banned
				echo "Sending screenshot failed. This account is still suspended for 5 minutes for creating a bit too many screenshots in a short period of time.";
				return;
			}
		} else{
			// Check if user has to be banned 
			$count = $database->count("log", 
			array( "AND" => array( 
					"timestamp[<>]" => [($currentTimeStamp - 60), ($currentTimeStamp)],
					'email_id' => $emailId
				)
			));
			if($count > 30){
				// More than 30 screenshots in the last minute, ban
				$database->update('accounts', array(
					'banned_timestamp' => $currentTimeStamp
				),array(
					'id' => $emailId
				));
				$database->delete("log", array(
					'email_id' => $emailId
				));
				echo "Sending screenshot failed. This account has been suspended for 5 minutes for creating a bit too many screenshots in a short period of time.";
				return;
			} 
			if($count > 150){
				// Clean up logs if needed
				$database->delete("log", array(
					'email_id' => $emailId
				));
			}
		}
	}

logCreatedScreenshot();
prepareScreenshotMail();
	
$fileName = "";
$strippedFileName = "";
	
function prepareScreenshotMail(){
	global $fileName, $strippedFileName, $image;
	$fileName = "screenshot".date("Y-m-d H:i:s").".png";
	$strippedFileName = str_replace(":","",$fileName);
	$strippedFileName = str_replace("-","",$strippedFileName);
	$strippedFileName = str_replace(" ","",$strippedFileName);

	
	base64_to_png($image, $fileName);
	$subject = "Captured a screenshot with Screenshotter at ".date("Y-m-d H:i:s");
	$body = '
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>Verification Email</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td style="padding: 20px 0 30px 0;">
                <table align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border: 1px solid #cccccc;">
                     <tr>
                          <td>
                              <table align="center" border="0" cellpadding="0" cellspacing="0" width="600">
                                 <tr>
                                     <td align="center" bgcolor="#39aad4" style="padding: 20px 0 10px 0;">
                                        <img src="http://www.marijnzwemmer.com/screenshotmailer/logo.jpg" width="128" height="128" style="display: block;" />
                                    </td>
                                 </tr>
                                 <tr>
                                  <td bgcolor="#ffffff" style="padding: 10px 30px 10px 30px; color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 20px;">
                                    <p>
                                      <center>Screenshot captured with Screenshot Mailer at <b>'.date("Y-m-d H:i:s").'</b>:<br /><center>
                                      <br />
                                      <center><img src="cid:screenshot"><br/><center>
                                    </p>
                                    <p>
                                        <center>Thank you for using Screenshot Mailer!<center>
                                    </p>
                                  </td>
                                 </tr>
                                 <tr>
                                  <td bgcolor="#ee4c50" style="padding: 20px 30px 20px 30px; color: #ffffff; font-family: Arial, sans-serif; font-size: 16px; line-height: 20px;">
                                      Screenshot Mailer<br />
                                      <a style="color:#ffffff" href="mailto:marijn@marijnzwemmer.com">marijn@marijnzwemmer.com</a>
                                  </td>
                                 </tr>
                                </table>
                          </td>
                     </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';

	writeMail($subject, $body, true);
}

function prepareActivationMail(){
	global $emailAddress;
	$body = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>Verification Email</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td style="padding: 20px 0 30px 0;">
                <table align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border: 1px solid #cccccc;">
                     <tr>
                          <td>
                              <table align="center" border="0" cellpadding="0" cellspacing="0" width="600">
                                 <tr>
                                     <td align="center" bgcolor="#39aad4" style="padding: 20px 0 10px 0;">
                                        <img src="http://www.marijnzwemmer.com/screenshotmailer/logo.jpg" width="128" height="128" style="display: block;" />
                                    </td>
                                 </tr>
                                 <tr>
                                  <td bgcolor="#ffffff" style="padding: 10px 30px 10px 30px; color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 20px;">
                                    <p>
                                        Thank you for using Screenshot Mailer!
                                    </p>

                                    <p>
                                        We would like you to verify that you want to receive emails from us. Please go here to verify your email address:<br />
                                        <br />
                                        <a href="http://www.marijnzwemmer.com/screenshotmailer/VerifyEmailAccount.php?emailaddress='.$emailAddress.'">http://www.marijnzwemmer.com/easyscreenshot/VerifyEmailAccount.php?emailaddress='.$emailAddress.'</a></br>
                                        <br />
										<br />
                                        If you have no idea what this is about, please ignore and delete this email.
                                    </p>

                                    <p>
                                        Thank you,<br />
                                        The Screenshot Mailer team
                                    </p>
                                  </td>
                                 </tr>
                                 <tr>
                                  <td bgcolor="#ee4c50" style="padding: 20px 30px 20px 30px; color: #ffffff; font-family: Arial, sans-serif; font-size: 16px; line-height: 20px;">
                                      Screenshot Mailer<br />
                                      <a style="color:#ffffff" href="mailto:marijn@marijnzwemmer.com">marijn@marijnzwemmer.com</a>
                                  </td>
                                 </tr>
                                </table>
                          </td>
                     </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';
	
	
	
	$subject = "Easy Screenshot Verification";
	writeMail($subject, $body, false);
}

function logCreatedScreenshot(){
	global $database, $emailAddress, $emailId;
	$totalScreenshots = $database->select("accounts",array(
		"total_screenshots"
	),array(
		"email" => $emailAddress
	))[0]['total_screenshots'];
	
	$totalScreenshots++;
	$database->update('accounts', array(
		'total_screenshots' => $totalScreenshots
	),array(
		'email' => $emailAddress,
	));
	
	$database->insert('log', array(
		'email_id' => $emailId,
		'timestamp' => date_timestamp_get(date_create())
	));
}

function base64_to_png($base64_string, $output_file) {
    $ifp = fopen($output_file, "wb"); 

    fwrite($ifp, base64_decode($base64_string)); 
    fclose($ifp); 

    return $output_file; 
}

function writeMail($subject, $body, $addEmbededImage){
	global $fileName, $strippedFileName, $emailAddress;
	$mail = new PHPMailer();
	$mail->IsSMTP();                                      // set mailer to use SMTP
	$mail->Host = "smtp.mail.pcextreme.nl";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->Username = "marijn@marijnzwemmer.com";  // SMTP username
	$mail->Password = "dabest12"; // SMTP password

	$mail->From = "screenshotter@marijnzwemmer.com";
	$mail->FromName = "Screenshotter";
	$mail->AddAddress( $emailAddress);
	$mail->AddReplyTo("noreply@marijnzwemmer.com");

	$mail->WordWrap = 50;                                 // set word wrap to 50 characters
	if($addEmbededImage){
		$mail->AddEmbeddedImage($fileName, "screenshot", $strippedFileName);         			  // add embedded image
	}
	$mail->IsHTML(true);                                  // set email format to HTML

	$mail->Subject = $subject;
	$mail->Body    = $body;
	$mail->AltBody = "HTML isn't supported in your mail-client, here is the HTML raw code anyhow:<br>".$body;

	if(!$mail->Send())
	{
	   echo "Mail not sent: " . $mail->ErrorInfo;
	   exit;
	}

	echo "Email sent. ";
}

?>