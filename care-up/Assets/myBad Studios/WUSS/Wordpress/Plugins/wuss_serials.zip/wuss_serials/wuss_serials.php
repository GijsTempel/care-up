<?php

/*
Plugin Name: WUSS Serial Management
Plugin URI: http://wuss.mybadstudios.com/
Description: A plugin that allows you to create and manage registration keys for your products
Version: 1.0
Author: myBad Studios
Author URI: http://www.mybadstudios.com
*/

function activate_wuserials()
{
	include_once(dirname(__FILE__) . "/../wuss_login/functions.php");

	$data_table	=	"CREATE TABLE IF NOT EXISTS "
					. wuss_prefix
					."serials (
						  suid integer UNSIGNED AUTO_INCREMENT,
						  gid integer UNSIGNED NOT NULL DEFAULT 0,
						  uid integer UNSIGNED NOT NULL DEFAULT 0,
						  serial varchar(32) NOT NULL DEFAULT '',
						  reserved TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
						  PRIMARY KEY  (suid,gid,serial)
						);";
						
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($data_table);
}

function deactivate_wuserials(){
	//currently don't have anything to do here...
}

function uninstall_wuserials() {
	include_once(dirname(__FILE__) . "/../wuss_login/functions.php");
   	//delete the table created by this kit...
	global $wpdb;
    $query = "DROP TABLE ". wuss_prefix ."serials;";
	//$wpdb->query($query);
}

register_activation_hook( __FILE__,	'activate_wuserials'	);
register_deactivation_hook( __FILE__,	'deactivate_wuserials'	);
register_uninstall_hook( __FILE__,	'uninstall_wuserials'	);

include_once(dirname(__FILE__) ."/settings.php");
include_once(dirname(__FILE__) ."/classes/WussSerials.class.php");
include_once(dirname(__FILE__) ."/wuss_game_purchase.php");

