<?php
class WussSerials {
	var $uid = 0,
		$gid = 0,
		$suid = 0,
		$serial = "",
		$table,
	    $data;
	
	public function __construct($gid, $uid)
	{
		$this->uid	= $uid;
		$this->gid	= $gid;
			
	   	$this->table = wuss_prefix . "serials";
	}
	
	function _generate()
	{
		if (function_exists('com_create_guid') === true)
        return trim(com_create_guid(), '{}');

		$data = openssl_random_pseudo_bytes(16);
		$data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
		$data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
		return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
	}
	
	//The GUID is an optional field for added security. Entirely optional but if it is provided, it is used
	//By default, every serial per game has a unique key
	public function IsGameLicensed()
	{
		$suid = Postedi('suid');
		if ($suid > 0)
			return (null !== $this->FetchSerial(true, $suid) );

		return (null !== $this->FetchSerial());
	}	
		
	//fetch all serials generated for this game
	public function FetchAllSerials()
	{
		global $wpdb;
		$this->data = $wpdb->fetch_results("SELECT suid,uid,serial,reserved FROM $this->table WHERE gid = $this->gid");
		return ($this->data !== null);
	}
	
	//fetch either all available or all allocated serials for the specified game
	public function FetchSerials($available = true, $reserved = 0)
	{
		global $wpdb;
		$query = "SELECT " 
		. ($available ? '' : 'uid,')
		. "serial FROM $this->table WHERE gid = $this->gid AND uid " 
		. ($available ? "= 0" : "<> 0")
		. "AND reserved='$reserved'";
		$this->data = $wpdb->get_results($query, ARRAY_A);
		return (null !== $this->data);
	}
	
	//fetch the serial belonging to this user
	public function FetchSerial($from_suid = false, $suid = -1)
	{
		global $wpdb;
		$query = "SELECT serial FROM $this->table WHERE uid = '$this->uid' AND gid = '$this->gid'" 
			   . ($from_suid ? " AND suid = $suid" : '');
		$this->data = $wpdb->get_var($query);
		if ($this->data) 
			return $this->data;
		else
			return null; //make sure to return null, not 0
	}
	
	public function RegisterWithSerial($serial)
	{
		global $wpdb;

		//test if serial already belongs to someone else or whether it is available
		$existing_user = $wpdb->get_var("SELECT uid FROM $this->table WHERE serial ='$serial'");
		if (null === $existing_user || $existing_user == 0) {
			$response = $wpdb->update($this->table,
				array('uid' => $this->uid), array('gid' => $this->gid, 'serial' => $serial));
			return ($response !== false && $response > 0);
		}
		else
		{
			$admin_email = get_option('admin_email');
			$subject = "Duplicate license use detected";
			$game_name = $wpdb->get_var("SELECT post_title FROM $wpdb->posts WHERE ID ='$this->gid'");
			$new_user = new WP_User($this->uid);

			$verify_account = $wpdb->get_var("SELECT ID FROM $wpdb->users WHERE ID='$existing_user'");
			if (null === $verify_account)
			{
				$username = 'an unregistered user';
				$to = $admin_email;
			} else {

				//if the owner is trying to register his own game again, do nothing
				if($verify_account == $this->uid)
					return true;

				$user = new WP_User($existing_user);
				$username = "$user->user_login ($user->first_name $user->last_name)";
				$to = $user->user_email;
			}
			$message = "Serial $serial belonging to $username was just used by $new_user->user_login ($new_user->first_name $new_user->last_name) to register $game_name";

			//if the original user no longer has an account just let the admin know that the serial has changed hands / become public knowledge
			if (null === $verify_account)
				wp_mail($to, $subject, $message);
			//otherwise inform the owner that his serial was used by someone else and inform the site admin also
			else
				wp_mail($to, $subject, $message, array("BCC: $admin_email"));
			SendToUnity(SendField("foo","barman"));
			return false;
		}
	}

	//This function is ideal for use by registration server endpoints should you have any
	public function LicenseGameToUser($reserved = 0)
    {
        global $wpdb;
        $admin_email = get_option('admin_email');

        if ($this->gid < 1 || $this->gid == '') {
            $time = date("Y-m-d h:i:sa");
            $message = "A license for an unknown game {$this->gid} was requested at {$time}";
            wp_mail($admin_email, 'Invalid licensing attempt', $message);
            return;
        }
        $game_name_query = "SELECT post_title FROM $wpdb->posts WHERE ID = '{$this->gid}'";
        $game_name = $wpdb->get_var($game_name_query);

        if ($this->uid < 1 || $this->uid == '') {
            $message = "A license for game {$this->gid}({$game_name}) was requested for an invalid user: $this->uid";
            wp_mail($admin_email, 'Invalid licensing attempt', $message);
            return;
        }
        $user = $wpdb->get_var("SELECT user_login FROM $wpdb->users WHERE ID = '$this->uid'");
        $serial = $wpdb->get_var("SELECT serial FROM $this->table WHERE uid = '0' AND gid='$this->gid' AND reserved='$reserved'");
        if (null === $serial)
        {
            $game_name = $wpdb->get_var("SELECT post_title FROM $wpdb->posts WHERE ID = '$this->gid'");
            $message = "A serial for game {$this->gid}({$game_name}) was requested for user $user but no available serial could be found";
            wp_mail($admin_email, 'Invalid licensing attempt', $message);
            return;
        }
        $result = $this->RegisterWithSerial($serial);
        if ($result === false)
        {
            $game_name = $wpdb->get_var("SELECT post_title FROM $wpdb->posts WHERE ID = '$this->gid'");
            $user = $wpdb->get_var("SELECT username FROM $wpdb->users WHERE ID = '$this->uid'");
            $message = "Serial $serial for game {$this->gid}({$game_name}) was allocated to user $user but allocation failed. Please double check";
            wp_mail($admin_email, 'Invalid licensing attempt', $message);
        } else
        {
            $user_email = $wpdb->get_var("SELECT user_email FROM $wpdb->users WHERE ID = '$this->uid'");
            $blogname = get_option('blogname');

            $siteurl = get_option('siteurl');
            $subject = "Purchase confirmation from " . $blogname;
            $message = "<h1>Your purchase was successful</h1><p>Your serial for <strong>$game_name</strong> is:  $serial</p>"
                     . "<p>The game has already been registered to this serial so you won't need to manually register using it."
                     . "Please keep it safe as you may need it when contacting customer support</p><p>Thank you for your"
                     . "purchase. We hope you are happy with it.</p><p><strong>$blogname</strong><br>"
                     . "<a href=\"$siteurl\">$siteurl</a></p>";
            wp_mail($user_email, $subject, $message, array("From: $admin_email","Content-type: text/html"));
        }
    }
	
	//generate new serials for your game
	public function GenerateSerials($amount = 1, $reserved = 0)
	{
		global $wpdb;
		
		$created = 0;
		$serials = '';
		$values = '';

		//generate the serials
		while($created++ < $amount)
			$serials .= ",'".$this->_generate()."'";
        $serials = substr($serials, 1);

		//as unlikely as it may be, look for duplicates and get rid of them
		$query = "SELECT serial FROM $this->table WHERE serial in ($serials) AND gid = $this->gid";
		$tests = $wpdb->get_results($query, ARRAY_N);
		$serials = str_replace("'", "", $serials);
		$serials_a = explode(',', $serials );
		$serials_a = array_diff($serials_a, $tests);
		
		//add the serials to the table
		$query = "INSERT INTO $this->table (gid,serial,reserved) VALUES ";
		foreach($serials_a as $key => $val)
			$values .= ",($this->gid, '$val', '$reserved')";
		$query .= substr($values, 1); 
		$result = $wpdb->query($query);
		return $result;
	}
		
	//fetch a list of all the games this player has registered to his account
	public function FetchRegisteredGames()
	{
		global $wpdb;
			
		$query = "SELECT DISTINCT gid FROM $this->table WHERE uid = $this->uid";
	
		$this->data = $wpdb->get_results($query);
		return $this->data;
	}
		
	//make a serial available for re-issue to another player
	//can only be registered to one user at a time so piracy is not a concern here
	public function RemoveRegistration($serial)
	{
		global $wpdb;
		$response = $wpdb->update($this->table,
		array('uid' => 0), array('gid' => $this->gid, 'serial' => $serial) );
		return $response;
	}
}
