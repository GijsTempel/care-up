<?php
//load this first as this makes sure the WP themes are not processed
include_once(dirname(__FILE__) . "/../wuss_login/settings.php");

function serialsLoadClasses()
{
    include_once(dirname(__FILE__) . "/classes/WussSerials.class.php");
}

//fetches the currently logged in user's serial for the selected game
function serialsFetchSerialNumber()
{
    global $current_user;

    $serials = new WussSerials(Postedi('gid'), $current_user->ID);
    $serial = $serials->FetchSerial();
    if ( null != $serial )
    {
        SendToUnity(SendField('serial', $serial));
    } else
    {
        SendToUnity(PrintError("Not licensed"));
    }
}

//test if a serial is valid for a selected user
function serialsValidateRegistration()
{
    global $current_user;

    $serials = new WussSerials(Postedi('gid'), $current_user->ID);
    if ( $serials->IsGameLicensed() )
    {
        SendToUnity(SendField('valid','true'));
    } else
    {
        SendToUnity(PrintError("Not licensed"));
    }
}

//assign a serial to a user
function serialsRegisterSerial()
{
    global $current_user;

    $serials = new WussSerials(Postedi('gid'), $current_user->ID);
    if ( $serials->RegisterWithSerial(Posted('serial')) )
    {
	    SendToUnity(SendField('serial', $serials->FetchSerial()));
    }
    else
    {
        SendToUnity(PrintError("Invalid serial number provided"));
    }
}
