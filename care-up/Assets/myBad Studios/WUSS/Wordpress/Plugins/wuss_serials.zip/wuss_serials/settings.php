<?php		
include_once(dirname(__FILE__) . "/../wuss_login/functions.php");
include_once("Settings/wuss_serials.php");

add_filter("wuss_section_heading", "wuss_add_serials_menu",23,2);
add_filter("wuss_section_content", "wuss_show_serials_section", 25, 2);

function wuss_add_serials_menu($value)
{
    $menu_button = new WussMenuItem('Serials');
    return $value . $menu_button->GenerateMenuButton();
}

function wuss_show_serials_section($content, $test)
{
    return (MENUTAB == SERIALS_CONSTANT) ? show_wuss_serials_content() : $content;
}
