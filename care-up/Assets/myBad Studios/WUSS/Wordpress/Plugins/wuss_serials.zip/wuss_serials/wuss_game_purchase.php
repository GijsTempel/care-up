<?php
add_action( 'wuss_purchase', 'wuss_game_purchase' );

function wuss_game_purchase($args)
{
	//if the type of this transaction is not "game"
	//then this transaction was not meant for this plugin so quit
	if( $args['type'] != "game" )
		return;

	$uid = intval($args['uid']);
	$gid = intval($args['gid']);

	$serials = new WussSerials($gid, $uid);
	$serials->LicenseGameToUser();
}
