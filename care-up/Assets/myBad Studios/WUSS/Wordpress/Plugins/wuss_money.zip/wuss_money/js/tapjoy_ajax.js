
function wuss_tapjoy_setvalue(path, platform, gid)
{
    var xmlhttp =new XMLHttpRequest();
    xmlhttp.onreadystatechange=function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            if ('' != xmlhttp.responseText)
                alert(xmlhttp.responseText);
        }
    }

    var field_name = "wuss_tapjoy_secret_" + platform;
    var value = document.getElementById(field_name).value;
    var formData = new FormData();
    formData.append("gid", gid );
    formData.append("platform", platform );
    formData.append("value", value);
    formData.append('action', 0); // action 0 and 1 are in use by the Book Bondage meta options

    xmlhttp.open("POST", path + "/wuss_money/ajax/tapjoy_ajax.php",true);
    xmlhttp.send(formData);
}

