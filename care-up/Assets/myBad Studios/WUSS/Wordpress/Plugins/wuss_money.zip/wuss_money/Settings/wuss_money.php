<?php

function show_wuss_money_content()
{
	if (!current_user_can('manage_wuss')) {
		return __('You do not have sufficient permissions to access this page.');
		wp_die('');
	}

	$sections = array("Settings", "User Info");
	define('MENUSUB', Posted('menu_sub') == '' ? $sections[0] : Posted('menu_sub'));

	$output = '
		<h2>WUMoney Configuration</h2>
		<form method="post"><input type="hidden" name="menu_tab" value="'.MENUTAB.'">
		<div style="width:864px; border:1px solid; margin-left:2px; padding: 5px;">
		<input type="'.(MENUSUB == $sections[0] ? "button" : "submit").'" name="menu_sub" value="'.$sections[0].'" class="button-'.(MENUSUB == $sections[0] ? "secondary": "primary").'">
		<input type="'.(MENUSUB == $sections[1] ? "button" : "submit").'" name="menu_sub" value="'.$sections[1].'" class="button-'.(MENUSUB == $sections[1] ? "secondary": "primary").'">
		</div>
		</form>
		';

	switch(MENUSUB)
	{
		case "User Info":
			$output .= DrawUserInfo();
			break;

		default:
			$output .= DrawSettings();
			break;
	}

	return $output;
}

function AllUserSearchField()
{
	$output = "<form method=POST>"
		."<input type='text' name='wuss_find_user'>"
		. "<input type='submit' class='button-secondary inputbutton' name='wuss_serial_action' value='Search'>"
		. '<input type="hidden" name="menu_tab" value="' . MENUTAB . '">'
		. '<input type="hidden" name="menu_sub" value="' . MENUSUB . '">'
	;
	$output . "</form>";
	return $output;
}

function GetBalancesForGame($gid, $game, $uid)
{
	global $wpdb;
	$results = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->usermeta WHERE user_id = '$uid' AND meta_key LIKE '{$gid}_currency_%'");
	$styling = 'style="border: 1px solid; padding-left: 15px"';

	$output = '
	<tr><td colspan="2" class="stattableheader">'.$game.'</td></tr>
	<tr><td style="background-color:gray; color:white; padding:5px;" class="inputfield">Currency</td>
	<td style="background-color:gray; color:white" class="inputfieldlong">Balance</td></tr>';
	if (!$results)
		return $output . "<tr><td colspan=2 $styling>None...</td></tr>";

	foreach ($results as $entry)
	{
		$elements = explode('_', $entry->meta_key);
		$output .= "
			<tr><td $styling>$elements[2]</td><td $styling>
			<form method=post>
			<table width=100% style=\"border:0px; margin:0px; padding:0px;\">
			<tr><td width=\"*\">
			<input type=text name=balance value=\"{$entry->meta_value}\">
			<input type=hidden name=\"menu_tab\" value=\"".MENUTAB."\">
			<input type=hidden name=\"menu_sub\" value=\"".MENUSUB."\">
			<input type=hidden name=uid value=\"{$uid}\">
			<input type=hidden name=gid value=\"{$gid}\">
			<input type=hidden name=meta_key value=\"$entry->meta_key\">
			</td><td style=\"width:100px\">
			<input type=submit name=action_request class=\"button-primary\" value=\"Update Balance\">
			</td></tr></table>
			</form></td>";
	}
	return $output;
}

function GetTransactionHistoryForGame($money_obj, $gid, $uid, $game_name)
{
	$results = '';
	$cell_styling = 'style="background-color:gray; color:white; padding:5px; width:';
	$logs = $money_obj->GetTransactionHistory($uid, $gid);
	if ($logs) {
		$results .= '
					<tr><td colspan="5" class="wuss_table_striped stattableheader">' . $game_name . '</td></tr>
					<tr>
					<td '.$cell_styling.'30%">Awarded</td>
					<td '.$cell_styling.'18%">Currency</td>
					<td '.$cell_styling.'10%">Amount</td>
					<td '.$cell_styling.'37%">Transaction</td>
					<td '.$cell_styling.'15%">Source</td>
					</tr>';
		foreach($logs as $log)
		{
			$results .= "
						<td>$log->awarded</td>
						<td>".($log->source == 'Tapjoy' ? 'points' : explode('-',$log->transaction)[0])."</td>
						<td>$log->amount</td>
						<td>$log->transaction</td>
						<td>$log->source</td>
						</tr>
						";
		}
	}
	return $results;
}

function DrawUserInfo()
{
	global $wpdb;
	$uid = Postedi('uid');

	if (isset($_REQUEST['wuss_serial_action']) && ($_REQUEST['wuss_serial_action'] == 'Search') ) {
		$user_to_find = Posted(wuss_find_user);
		$search_result = $this->GetSingleUserByName($user_to_find);
		if ($search_result > 0) {
			$uid = $search_result;
			$_REQUEST['uid'] = $uid;
		}
	}

	$users_obj = new WussUsers();
	$games = new WussGames();
	$all_games = ($games->GameCount() > 0) ? $games->GetAllGames() : null;

	if ($_REQUEST['action_request'])
	{
		switch($_REQUEST['action_request'])
		{
			case "Update Balance":
				$amt = intval($_REQUEST['balance']);
				$meta_key = $_REQUEST['meta_key'];

				if (!is_numeric($amt))
					break;

				$key = array('user_id' =>$uid, 'meta_key' => $meta_key);
				if ($amt <= 0)
					$wpdb->delete($wpdb->usermeta, $key);
				else
					$wpdb->update($wpdb->usermeta, array('meta_value' => $amt), $key);
				break;
		}
	}

	$users_list = '
		<table><tr><td>
		<form method="POST"><input type="hidden" name="menu_tab" value="'.MENUTAB.'">
		<form method="POST"><input type="hidden" name="menu_sub" value="'.MENUSUB.'">' .
		$users_obj->DropDownList(0, $uid, Posted('ufilter')) .
		$users_obj->FilterDropDown(Posted('ufilter')) . '
		</form>
		</td><td>' .
		AllUserSearchField( ) .'
		</td></tr></table>';

	$balances_display = '';
	if ($all_games)
	{
		$balances_display = '<table class="wuss_table_striped stattable">';
		$balances_display .= GetBalancesForGame(0, "Shared", $uid);
		foreach ($all_games->posts as $entry)
			$balances_display .= GetBalancesForGame($entry->ID, $entry->post_title, $uid);
		$balances_display .= '</table>';
	}

	$transaction_history = '';
	if ($all_games)
	{
		$money_obj = wussMoney::construct($uid,0,0);

		$transaction_history = '<tr>
			<td valign="top" class="wuss_settings_description">Transaction history</td>
			<td valign="top" class="wuss_settings_values" style="width:664px"><table style="width:600px; border:1px solid">';
		$transaction_history .= GetTransactionHistoryForGame($money_obj, 0, $uid, 'Shared');
		foreach ($all_games->posts as $entry)
			$transaction_history .= GetTransactionHistoryForGame($money_obj, $entry->ID, $uid, $entry->post_title);
		$transaction_history .= '</table></td></tr>';

	}

	$output = '
		<table class="wuss_table_striped">
		<tr><td valign="top" class="wuss_settings_description">Select user</td>
		<td valign="top" class="wuss_settings_values" style="width:664px">' .
		$users_list .'
		</td></tr>
		
		<tr><td valign="top" class="wuss_settings_description">Balances</td>
		<td valign="top" class="wuss_settings_values">' .
		$balances_display .'
		</td></tr>		
		' . $transaction_history;

	return $output;
}

function DrawSettings()
{
	//See what game we are working with
	$gid = Postedi("gid");

	//first determine if there are more than 1 game id
	$games = new WussGames();
	$output = '';
	if ( $games->GameCount() == 0)
	{
		$output .= '<div class=error><pre>No game data found...</pre></div>';
		return $output;
	}

	//make sure we are dealing with a game, at least...
	if ($gid == 0)
		$gid = $games->GetFirstGameID();

	$games_dropdown = '<form method=post style="width:220px">'
	                  . '<input type=hidden name="menu_tab" value="' . MENUTAB . '">'
	                  . $games->GamesDropDownList($gid, true, "gid", "", '','submit')
	                  . '</form><br>';

	$output .= '<table class="wuss_table_striped">'
	           .  '<tr><td valign="top" class="wuss_settings_description">'
	           .  'Select Game'
	           .  '</td><td valign="top" class="wuss_settings_values" style="width:664px">'
	           .  (($games->GameCount() > 0) ? $games_dropdown : '')
	           .  '</td></tr>';

	$output .=   wuss_tapjoy_settings($gid, 'ios' )
	           . wuss_tapjoy_settings($gid, 'android');

	$output .=  '</table>';

	return $output;
}

function wuss_tapjoy_settings($gid, $platform)
{
	$path = plugins_url();
	$value = get_post_meta($gid,'tapjoy_currency_secret_'."{$platform}", true);
	if (empty($value)) $value = 'empty';
	$output ='<tr><td valign="top" class="wuss_settings_description">Currency secret key '.$platform.
             '</td><td valign="top" class="wuss_settings_values">'.
             "<input type=\"text\" id=\"wuss_tapjoy_secret_{$platform}\" value=\"{$value}\" class=\"inputfieldlong\">".
             '<input type="button" class="button-secondary" value="Update" onclick="JavaScript:wuss_tapjoy_setvalue('.
	         "'{$path}', '{$platform}', '{$gid}' )\" >".
			 '</form></td></tr>';
	return $output;
}
