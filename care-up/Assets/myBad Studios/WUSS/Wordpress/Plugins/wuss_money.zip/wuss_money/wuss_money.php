<?php

session_start();

/*
Plugin Name: WUSS Money
Plugin URI: http://wuss.mybadstudios.com/
Description: Use multiple virtual currencies in your projects. Also includes a Self Managed Currency Server for Tapjoy that assigns Tapjoy points per user account instead of per device
Version: 1.0
Network: true
Author: myBad Studios
Author URI: http://www.mybadstudios.com
*/

include_once(dirname(__FILE__) ."/settings.php");
include_once(dirname(__FILE__) ."/classes/wussMoney.class.php");

function activate_wumoney()
{
	include_once(dirname(__FILE__) . "/../wuss_login/functions.php");

	$tapjoy_log  = "CREATE TABLE IF NOT EXISTS "
	                  ."`wuss_money_awards_log` (
	                   `guid` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
	                   `gid` INT UNSIGNED NOT NULL , 
	                   `uid` INT UNSIGNED NOT NULL , 
	                   `awarded` TIMESTAMP DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP NOT NULL , 
	                   `amount` INT UNSIGNED NOT NULL DEFAULT '0' , 
	                   `transaction` VARCHAR(128) NOT NULL DEFAULT '' ,
	                   `source` VARCHAR(16) NOT NULL DEFAULT '',
	                   PRIMARY KEY (`guid`)) ENGINE = InnoDB;";

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($tapjoy_log);
}

function deactivate_wumoney(){
	//currently don't have anything to do here...
}

function uninstall_wumoney() {
	include_once(dirname(__FILE__) . "/../wuss_login/functions.php");
	global $wpdb;
	//uncomment the following line if you are sure you want to delete the transactions log when you uninstall this kit
	//$wpdb->query("DROP TABLE wuss_money_awards_log;");
}

include_once(dirname(__FILE__) ."/settings.php");
include_once(dirname(__FILE__) ."/wuss_money_purchases.php");

register_activation_hook( __FILE__,	'activate_wumoney'	);
register_deactivation_hook( __FILE__,	'deactivate_wumoney'	);
register_uninstall_hook( __FILE__,	'uninstall_wumoney'	);

add_action( 'woocommerce_payment_complete',	'wusales_woo_payment_complete' );
function wusales_woo_payment_complete( $order_id ) {
	global $wpdb;

	$order = new WC_Order( $order_id );

	//since we are updating account settings, exit if this is a guest....
	$uid = $order->get_user_id();
	if ($uid == 0) return;

	foreach ($order->get_items() as $item_id => $item)
	{
		if ($item['quantity'] <= 0) continue;

		$product = wc_get_product($item['product_id']);
		if (!$product) continue;

		$item_data = $item->get_data();
		$sku = $product->get_sku();

		//all WUSS sellable items must start with WUSKU_{GameID}_{WussProductType} so test if this is such an item
		//Example SKU: WUSKU_8_MONEY_gold_200
		//in this instance if the user bought 3 of these items then we know to give him 3x 200 gold currency
		if (strpos($sku, "WUSKU_") !== 0)
			continue;

		$strings = explode("_",$sku);
		if (count($strings) < 3)
			continue;

		array_shift($strings);
		$gid = intval( array_shift($strings) );
		$type = strtolower(array_shift($strings));

		//let's just validate the GID is valid before we proceed...
		//this should be tested during design time so we are just letting the admin know that the SKU needs updating
		if ( $gid > 0 ) :
			$validate = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE ID='$gid'");
			if (!$validate)
			{
				wp_mail(
					get_option('admin_email'),
					'Invalid GID specified for product',
					"Attempted to sell an item for Game Id $gid. Please update the SKU: $sku");
				continue;
			}
		endif;

		if ( $product->is_purchasable() && $product->exists() && $product->is_virtual() && (!$product->is_downloadable() || $type == 'game')) :
			$args = array(
				'uid' => $uid,
				'gid'=> $gid,
				'type' => $type,
				'fields' => $strings,
				'qty' => $item['qty'],
				'data' => $item_data,
				'product' => $product
			);
			$args['meta'] = get_post_meta($args['data']->ID);
			do_action('wuss_purchase', $args);
		endif;
	}
}
