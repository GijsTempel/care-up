<?php
include_once(dirname(__FILE__) . "/../wuss_login/functions.php");
include_once("Settings/wuss_money.php");

add_filter("wuss_section_heading", "wuss_add_money_menu",19,2);
add_filter("wuss_section_content", "wuss_show_money_section", 21, 2);

function wuss_add_money_menu($value)
{
	$menu_button = new WussMenuItem('Money');
	return $value . $menu_button->GenerateMenuButton();
}

function wuss_show_money_section($content, $test)
{
	return (MENUTAB == MONEY_CONSTANT) ? show_wuss_money_content() : $content;
}

add_action( 'admin_enqueue_scripts', 'enqueue_wumoney_scripts' );

function enqueue_wumoney_scripts()
{
	wp_register_script( 'wuss_tapjoy_ajax_functions', plugins_url( 'js/tapjoy_ajax.js', __FILE__ ) );
	wp_enqueue_script( 'wuss_tapjoy_ajax_functions' );
}
