<?php
add_action( 'wuss_purchase', 'wuss_money_purchase' );

function wuss_money_purchase($args)
{
	//if the type of this transaction is not "money" then this transaction was not meant for this plugin so quit
	if( $args['type'] != "money")
		return;

	$uid = intval($args['uid']);
	$gid = intval($args['gid']);
	$currency = $args['fields'][0];
	$amount = (count($args['fields']) > 0) ? intval($args['fields'][1]) : 1;
	$amt_to_award = intval($args['qty']) * $amount;

	//force text formatting for 'points' currency
	if (strtolower($currency) == 'points')
		$currency = strtolower($currency);

	$points = wussMoney::construct($uid, $gid, $amt_to_award, $currency);
	if ($points->GivePoints() )
		$points->LogPurchase($currency);
}