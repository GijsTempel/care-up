<?php
define('WP_USE_THEMES', false );
require_once(dirname(__FILE__) . '/../../../../wp-config.php');

if (!is_user_logged_in() || !current_user_can('manage_wuss') ) return;
if (!isset($_REQUEST['action']) || $_REQUEST['action'] == '') return;

$action = (int)$_REQUEST['action'];
switch($action)
{
	case 0 : WussSaveTapjoyOption(); break;
}

function WussSaveTapjoyOption() {
	$gid = Postedi('gid');
	$platform = Posted('platform');
	$value = Posted('value');
	echo (false === update_post_meta($gid, 'tapjoy_currency_secret_'. $platform, $value)) ?
		"Update failed! GameID: $gid"  : "Updated {$platform} currency secret ";
}
