<?php

session_start();

/*
Plugin Name: WUSS Achievements
Plugin URI: http://wuss.mybadstudios.com/
Description: A plugin that allows you to create, award and report achievements
Version: 1.0
Author: myBad Studios
Author URI: http://www.mybadstudios.com
*/

//if these values don't exist, create them. If they do, then skip creating them
function activate_wuachievements()
{
//	include_once(dirname(__FILE__) . "/../wuss_login/functions.php");
}

function deactivate_wuachievements(){
	//currently don't have anything to do here...
}

function uninstall_wuachievements() {
   	//delete the tables created by this kit...
//	include_once(dirname(__FILE__) . "/../wuss_login/functions.php");
}

add_action( 'admin_enqueue_scripts', 'enqueue_wuss_achievements_styles' );
function enqueue_wuss_achievements_styles()
{
	wp_register_style ( 'wuss_achievements_stylesheet', plugins_url('wuss_achievements/Settings/ach_style.css'));
	wp_enqueue_style ( 'wuss_achievements_stylesheet' );
}

include_once (dirname(__FILE__) ."/settings.php");
include_once (dirname(__FILE__) ."/posttypes/wuss_achievement_type.php");
include_once (dirname(__FILE__) .'/classes/WussAchievements.class.php');

register_activation_hook( __FILE__,	'activate_wuachievements'	);
register_deactivation_hook( __FILE__,	'deactivate_wuachievements'	);
register_uninstall_hook( __FILE__,	'uninstall_wuachievements'	);
