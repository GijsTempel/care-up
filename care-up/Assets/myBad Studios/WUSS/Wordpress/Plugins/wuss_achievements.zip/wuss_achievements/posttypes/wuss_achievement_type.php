<?php
/* post types */
function wuss_achievements_post() {
	$labels = array(
		'name'                => _x( 'Achievement', 'Post Type General Name', 'text_domain' ),
		'singular_name'       => _x( 'Achievement', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'           => __( 'Achievements', 'text_domain' ),
		'parent_item_colon'   => __( 'Parent Achievement:', 'text_domain' ),
		'all_items'           => __( 'All Achievements', 'text_domain' ),
		'view_item'           => __( 'View Achievements', 'text_domain' ),
		'add_new_item'        => __( 'Add New Achievement', 'text_domain' ),
		'add_new'             => __( 'Add New', 'text_domain' ),
		'edit_item'           => __( 'Edit Achievement', 'text_domain' ),
		'update_item'         => __( 'Update Achievement', 'text_domain' ),
		'search_items'        => __( 'Search Achievements', 'text_domain' ),
		'not_found'           => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'text_domain' ),
	);
	$rewrite = array(
		'slug'                => 'wuss_achievement',
		'with_front'          => true,
		'pages'               => true,
		'feeds'               => true,
	);
	$args = array(
		'label'               => __( 'wuss_achievement', 'text_domain' ),
		'description'         => __( 'WUSS Achievements', 'text_domain' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail'),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => "wuss_framework",
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => false,
		'can_export'          => false,
		'has_archive'         => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'rewrite'             => $rewrite,
		'capability_type'     => 'page',
	);
	register_post_type( 'wuss_achievement', $args );
}

add_action( 'init', 'wuss_achievements_post', 0 );

if (is_multisite())
	add_action('network_admin_menu', 'add_wuss_achievements_submenu');

//WordPress doesn't allow multisites to display submenus for post types in the network dashboard so we do it ourselves
//this function will be moved to the wuss_login plugin eventually so let's just play it safe for the time being
if (!function_exists('wuss_add_submenus')) :
	function wuss_add_submenus($post_type, $text)
	{
		global $submenu, $menu, $_wp_real_parent_file, $_wp_submenu_nopriv;

		$permalink = admin_url( 'edit.php' )."?post_type={$post_type}";
		$menu_slug = plugin_basename( $permalink );
		$parent_slug = plugin_basename( 'wuss_framework');

		if ( isset( $_wp_real_parent_file[$parent_slug] ) )
			$parent_slug = $_wp_real_parent_file[$parent_slug];

		if ( !current_user_can( 'manage_wuss' ) ) {
			$_wp_submenu_nopriv[$parent_slug][$menu_slug] = true;
			return false;
		}

		if (!isset( $submenu[$parent_slug] ) && $menu_slug != $parent_slug )
		{
			foreach ( (array)$menu as $parent_menu )
			{
				if ( $parent_menu[2] == $parent_slug && current_user_can( $parent_menu[1] ) )
					$submenu[$parent_slug][] = array_slice( $parent_menu, 0, 4 );
			}
		}

		$submenu['wuss_framework'][] = array( $text, 'manage_wuss', $permalink );
	}
endif;

function add_wuss_achievements_submenu() {
	wuss_add_submenus('wuss_achievement', 'All Achievements');
}
/* End post types */

add_action( 'add_meta_boxes', 'wuss_locked_image_box' );
add_action( 'add_meta_boxes', 'wuss_ach_requirements_box' );
add_action( 'save_post', 'wuss_save_locked_image_meta_data' );
add_action( 'save_post', 'wuss_save_ach_requirements_meta_data' );

function wuss_ach_requirements_box() {
	add_meta_box(
		'wuss_ach_requirements_field_id',
		__( 'Achievement requirements', 'wuss_achievementdomain' ),
		'wuss_ach_requirements_meta_box_callback',
		'wuss_achievement',
		'advanced',
		'default'
	);

	add_meta_box(
		'wuss_game_select_id',
		__( 'Linked game', 'wuss_textdomain' ),
		'wuss_game_select_meta_box_callback',
		'wuss_achievement',
		'side'
	);

}

function wuss_locked_image_box() {

	$screens = array('wuss_achievement', 'wuss_item' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'wuss_locked_image_field_id',
			__( 'Locked Icon', 'wuss_achievementdomain' ),
			'wuss_locked_image_meta_box_callback',
			$screen,
			'side',
			'default'
		);
	}
}

function wuss_ach_requirements_table_row($type, $name, $qty)
{
	$trow = '<tr>
	<td><select name="reqType[]" class="reqTableContent">
		<option value="LT" '. ($type == "LT" ? 'selected' : '') .'>Must Not Have</option>
		<option value="GT" '. ($type == "GT" ? 'selected' : '') .'>Have At Least</option>
		<option value="EQ" '. ($type == "EQ" ? 'selected' : '') .'>Have Exactly</option></select></td>
	<td><input name="reqName[]" type="text" class="reqTableContent" value="'.$name.'"></td>
	<td><input name="reqQty[]" type="number" class="reqTableContent" value="'.$qty.'"></td>
	<td><button type=button class="reqRemoveButton">Remove</button></td></tr>';
	return $trow;
}

function wuss_ach_requirements_meta_box_callback($post) {
	wp_nonce_field( 'wuss_ach_requirements_meta_box', 'wuss_ach_requirements_meta_box_nonce' );
	$values = trim(get_post_meta( $post->ID, '_wuss_ach_requirements_value_key', true ));

	$table = '<div style="border:solid 1px"><form method="post" action="Process">
  
    <table class="AchievementReqTable" id="achReqTable">
        <tbody>
        <tr>
            <td id="header">Type</td>
            <td id="header">Name</td>
            <td id="header">Qty</td>
            <td id="header"></td>
        </tr>';

	if (strlen($values) > 0)
	{
		$entries = explode(',',$values);
		foreach($entries as $entry)
		{
			$fields = explode(' ', $entry);
			if (count($fields) != 3) continue;
			if (!is_numeric($fields[2])) $fields[2] = 0;
			$table .= wuss_ach_requirements_table_row($fields[0], $fields[1], $fields[2]);
		}
	}

    $table.= '</tbody></table>
    <br/>
        <input id="addButId" type="button" style="width:150px" value="Add Requirement">
 
    <br></div><br><input type="submit" style="width:150px" value="Save Requirements">
	</form>';
	echo $table;
}

function wuss_locked_image_meta_box_callback( $post ) {
	wp_nonce_field( 'wuss_locked_image_meta_box', 'wuss_locked_image_meta_box_nonce' );
	$valuel = get_post_meta( $post->ID, '_wuss_locked_image_value_key', true );

	echo '<br><table width="100%"><tr><td align="center">';
	if ($valuel == 0)
		echo '<img style="width:150px; height:150px; border:solid 1px #666;" id="img_locked_icon_field">';
	else
	{
		$img_src = wp_get_attachment_image_url( $valuel, 'medium' );
		echo '<img src="'.$img_src.'" id="img_locked_icon_field" class="wuss_preview_banner">';
	}
	echo '</td></tr> <tr>
	<td align="center"><input type="hidden" id="_locked_icon_field" name="_locked_icon_field" value="'.$valuel.'">
		<input class="button-secondary" type="button" target="_locked_icon_field" title="locked icon" id="_unique_wuss_button" value="Locked Icon" style="width:200px">
	</td>
	</tr>
	</table>';
}

function wuss_save_ach_requirements_meta_data( $post_id ) {
	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'manage_wuss', $post_id ) ) return;

	if ( isset( $_POST['wuss_ach_requirements_meta_box_nonce'] ) && wp_verify_nonce( $_POST['wuss_ach_requirements_meta_box_nonce'], 'wuss_ach_requirements_meta_box' ) )
	{
		if ( isset( $_POST['reqType'] ) )
		{
			$my_data = '';
			$entries = count($_POST['reqType']);
			for ($i = 0; $i < $entries;  $i++)
				$my_data .= ','.$_POST['reqType'][$i].' '.trim($_POST['reqName'][$i]).' '.$_POST['reqQty'][$i];
			if (strlen($my_data) > 0)
				$my_data = substr($my_data,1);

			update_post_meta( $post_id, '_wuss_ach_requirements_value_key', $my_data );
		}
	}
}

function wuss_save_locked_image_meta_data( $post_id ) {

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'manage_wuss', $post_id ) ) return;

	if ( isset( $_POST['wuss_locked_image_meta_box_nonce'] ) && wp_verify_nonce( $_POST['wuss_locked_image_meta_box_nonce'], 'wuss_locked_image_meta_box' ) )
	{
		if ( isset( $_POST['_locked_icon_field'] ) )
		{
			$my_data = sanitize_text_field( $_POST['_locked_icon_field'] );
			update_post_meta( $post_id, '_wuss_locked_image_value_key', $my_data );
		}
	}
}
