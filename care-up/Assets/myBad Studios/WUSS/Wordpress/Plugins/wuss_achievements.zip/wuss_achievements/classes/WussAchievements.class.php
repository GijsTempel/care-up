<?php

class WussAchievements {

	var $gid;
	var $uid;
	var $achievements = null;
	var $locked = null;
	var $obtained = null;

	var $obtained_key;

	public function __construct($gid, $uid=0)
	{
		$this->gid = $gid;
		$this->uid = $uid;
		$this->obtained_key = "{$gid}_achievements";

		$query = new WP_Query( array(
			'post_type' => 'wuss_achievement',
			'post_status' => 'publish',
			'orderby'   => 'post_title',
			'meta_query' => array(
				array(
					'key' => '_wuss_game_select_value_key',
					'value' => $this->gid,
					'compare' => '='
					)
				)
			)
		);
		$this->achievements = ($query->have_posts()) ? $query->posts : null;
		$this->__filter();
	}

	function __filter()
	{
		if (!$this->achievements) return null;
		$achieved = get_user_meta($this->uid, $this->obtained_key, true);
		if (!$achieved || trim($achieved) == '')
		{
			$this->__fetchLocked();
			return null;
		}

		$results = array();
		$badges = explode(',',$achieved);
		foreach($badges as $id)
		{
			foreach ($this->achievements as $achievement)
				if ($achievement->ID == $id)
					$results[] = $achievement;
		}
		$this->obtained = count($results) > 0 ? $results : null;
		$this->__fetchLocked();
		return $results;
	}

	function __fetchLocked()
	{
		if (null == $this->obtained) {
			foreach ($this->achievements as $entry)
				$this->locked[] = $entry;
			return;
		}

		foreach ($this->achievements as $entry)
		{
			if(!in_array($entry, $this->obtained))
				$this->locked[] = $entry;
		}
	}

	public function GetAchievement($id)
	{
		foreach($this->achievements as $entry)
			if ($entry->ID == $id)
				return $entry;
		return false;
	}

	public function IsObtained($id)
	{
		$entry = $this->GetAchievement($id);
		if ($entry !== false && $this->obtained)
			return in_array($entry, $this->obtained);
		return false;
	}

	public function UnlockAchievement($id)
	{
		$entry = $this->GetAchievement($id);
		if(!$entry) return false;
		if ($this->IsObtained($id)) return false;
		$index = array_search($entry, $this->locked);
		unset($this->locked[$index]);
		$this->locked = array_values($this->locked);
		$this->obtained[] = $entry;
		$this->__saveAchievements();
		return true;
	}

	public function LockAchievement($id)
	{
		$entry = $this->GetAchievement($id);
		if (!$entry) return false;
		if (!$this->IsObtained($id)) return false;
		$index = array_search($entry, $this->obtained);
		unset($this->obtained[$index]);
		$this->obtained = array_values($this->obtained);
		$this->locked[] = $entry;
		$this->__saveAchievements();
		return true;
	}

	public function ToggleObtainedState($id)
	{
		if ($this->IsObtained($id))
			$this->LockAchievement($id);
		else
			$this->UnlockAchievement($id);
	}

	function __saveAchievements()
	{
		$results = '';
		if (count ($this->obtained) > 0)
		{
			foreach ($this->obtained as $entry)
				$results .= ",{$entry->ID}";
		}
		if (strlen($results) > 0)
			$results = substr($results,1);
		update_user_meta($this->uid, $this->obtained_key, $results);
	}

	public function GetAllAchievements()
	{
		return $this->achievements;
	}

	public function GetObtained()
	{
		return $this->obtained;
	}

	public function GetLocked()
	{
		return $this->locked;
	}

	public function GetObtainedIDs()
	{
		$results = array();
		if ($this->obtained)
			foreach($this->obtained as $entry)
				$results[] = $entry->ID;
		return $results;
	}

	public function GetLockedIDs()
	{
		$results = array();
		if ($this->locked)
			foreach($this->locked as $entry)
				$results[] = $entry->ID;
		return $results;
	}

	public function GetObtainedCount()
	{
		return !$this->obtained ? 0 : count($this->obtained);
	}

	public function GetLockedCount()
	{
		return !$this->locked ? 0 : count($this->locked);
	}

	public function ShowAchievements($locked = true, $obtained = true, $size = 100, $interactive = false)
	{
		$result = "";

		if (!$this->achievements)
			return $result;

		$subset = $this->achievements;
		if (!$obtained) $subset = $this->locked;
		if (!$locked) $subset = $this->obtained;
		if (!$subset || count($subset) == 0)
			return $result;

		$style = "background-size: 100% 100%; background-repeat: no-repeat;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		border-radius: 15px; border: 2px solid #000; margin: 10px; float: left; width:{$size}px; height:{$size}px;";

		$interactive_text = '';
		foreach ($subset as $post)
		{
			$is_obtained = $this->IsObtained($post->ID);
			if ($is_obtained)
			{
				$img_src = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
			} else {
				$img_id = get_post_meta($post->ID, '_wuss_locked_image_value_key', TRUE);
				if (is_numeric($img_id))
					$img_src = wp_get_attachment_url($img_id);
				else
					$img_src = '';
			}
			if ($interactive)
			{
				$interactive_text = '
					<div style="padding: 0px; margin:10px 0;">
					<form method="post"><input type="hidden" name="menu_tab" value="'.MENUTAB.'">
					<input type="hidden" name="gid" value="'.$this->gid.'">
					<input type="hidden" name="uid" value="'.$this->uid.'">
					<input type="hidden" name="aid" value="'.$post->ID.'">
					<input type="submit" name="wuss_user_action" value="'.($this->IsObtained($post->ID) ? 'Remove' : 'Receive').
					'" style="height:25px; width:100%; padding:0px; background-color: #0f0f0f; margin:0px; color: whitesmoke; border: none;">'.
					'</form></div>';
			}

			$result .= '<div style="background: url('.$img_src.'); '.$style.'">'
				. $interactive_text
				. '</div>';
		}
		return $result;
	}

}