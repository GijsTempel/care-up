<?php
//load this first as this makes sure the WP themes are not processed
include_once(dirname(__FILE__) . "/../wuss_login/settings.php");

function awardLoadClasses()
{
	wuss_load_class('WussAchievements');
}

function __fetchEverything($uid)
{
	$result = '';
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$awards = $badges->GetAllAchievements();
	$unlocked = $badges->GetObtainedIDs();
	foreach ($awards as $award) {
		$result .= __postToCML($award, in_array($award->ID, $unlocked) ? '1' : '0');
	}
	SendToUnity($result);
}

function __fetchUnlocked($uid)
{
	$result = '';
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$awards = $badges->GetObtained();
	foreach ($awards as $award)
		$result .= __postToCML($award);

	SendToUnity($result);
}

function __fetchLocked($uid)
{
	$result = '';
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$awards = $badges->GetLocked();
	foreach ($awards as $award)
		$result .= __postToCML($award);

	SendToUnity($result);
}

function __fetchAchievement($uid)
{
	$result = '';
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$award  = $badges->GetAchievement(Postedi('aid'));
	if ($award)
		$result = __postToCML($award, $badges->IsObtained($award->ID));

	SendToUnity($result);
}

//fetch the id values of all obtained achievements as an array.
//Return the count to aid in determining if there was nothing to fetch
function __fetchUnlockedIds($uid)
{
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$entries = $badges->GetObtainedIDs();
	$results = SendField('count', count($entries));
	if (count($entries) > 0)
		$results .= SendField('achievements', implode(',', $entries));
	SendToUnity($results);
}

//fetch the id values of all locked achievements as an array.
//Return the count to aid in determining if there was nothing to fetch
function __fetchLockedIds($uid)
{
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$entries = $badges->GetLockedIDs();
	$results = SendField('count', count($entries));
	if (count($entries) > 0)
		$results .= SendField('achievements', implode(',', $entries));
	SendToUnity($results);
}

function __lockAchievement($uid)
{
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$badges->LockAchievement(Postedi('aid'));
	SendToUnity(SendField( 'unlocked', implode(',',$badges->GetObtainedIDs()) ));
}

function __unlockAchievement($uid)
{
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$badges->UnlockAchievement(Postedi('aid'));
	SendToUnity(SendField( 'unlocked', implode(',',$badges->GetObtainedIDs()) ));
}

function __toggleAchievement($uid)
{
	$badges = new WussAchievements( Postedi('gid'), $uid );
	$badges->ToggleObtainedState(Postedi('aid'));
	SendToUnity(SendField( 'unlocked', implode(',',$badges->GetObtainedIDs()) ));
}

function __isUnlocked($uid)
{
	$badges = new WussAchievements( Postedi('gid'), $uid );
	SendToUnity( SendField( 'unlocked', $badges->IsObtained( Postedi('aid') ) ) );
}

function __postToCML($post, $unlocked = false)
{
	$img_id = get_post_meta($post->ID, '_wuss_locked_image_value_key', TRUE);
	if (is_numeric($img_id))
		$locked_img_src = wp_get_attachment_url($img_id);
	else
		$locked_img_src = '';

	$result  = SendNode('achievement');
	$result .= SendField('aid', $post->ID);
	$result .= SendField('name', $post->post_title);
	$result .= SendField('text', $post->post_content);
	$result .= SendField('descr', $post->post_excerpt);
	$result .= SendField('locked_url', $locked_img_src);
	$result .= SendField('unlocked_url', wp_get_attachment_url( get_post_thumbnail_id($post->ID)));
	$result .= SendField('requirements', get_post_meta($post->ID, '_wuss_ach_requirements_value_key', true));
	if($unlocked) $result .= SendField('unlocked', 1);
	$result .= SendNode('/achievement');

	return $result;
}

function awardFetchEverything() { __fetchEverything(get_current_user_id()); }
function awardFetchUnlocked() { __fetchUnlocked(get_current_user_id()); }
function awardFetchLocked() { __fetchLocked(get_current_user_id()); }
function awardFetchAchievement() { __fetchAchievement(get_current_user_id()); }

function awardFetchUnlockedIDs() { __fetchUnlockedIds(get_current_user_id()); }
function awardFetchLockedIDs() { __fetchLockedIds(get_current_user_id()); }
function awardUnlockAchievement() { __unlockAchievement(get_current_user_id()); }
function awardLockAchievement() { __lockAchievement(get_current_user_id()); }
function awardToggleAchievement() { __toggleAchievement(get_current_user_id()); }
function awardIsAchievementUnlocked() { __isUnlocked(get_current_user_id()); }

function awardFetchUserUnlockedIDs() { __fetchUnlockedIds( Postedi('uid') ); }
function awardFetchUserLockedIDs() { __fetchLockedIds( Postedi('uid') ); }
function awardUnlockUserAchievement() { __unlockAchievement( Postedi('uid') ); }
function awardLockUserAchievement() { __lockAchievement( Postedi('uid') ); }
function awardToggleUserAchievement() { __toggleAchievement( Postedi('uid') ); }
function awardIsUserAchievementUnlocked() { __isUnlocked( Postedi('uid') ); }
