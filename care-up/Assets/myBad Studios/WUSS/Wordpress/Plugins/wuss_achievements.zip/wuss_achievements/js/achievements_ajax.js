$(document).ready(function(){
    $('#addButId').click(function(){
        trow=  "<tr>"+
            "<td><select name='reqType[]' class=\"reqTableContent\"><option value='LT'>Must Not Have</option><option value='GT'>Have At Least</option><option value='EQ'>Have Exactly</option></select></td>"+
            "<td><input name='reqName[]' type='text' class=\"reqTableContent\"></td>"+
            "<td><input name='reqQty[]' type='number' class=\"reqTableContent\"></td>"+
            "<td><button type='button' class='reqRemoveButton'>Remove</button></td></tr>";
        $('#achReqTable').append(trow);
    });
});

$(document).on('click', 'button.reqRemoveButton', function () {
    $(this).closest('tr').remove();
    return false;
});
