<?php

define('WP_USE_THEMES', false );
require_once($_SERVER['DOCUMENT_ROOT'].'/wp-load.php' );
?>
<!DOCTYPE html>
<html lang="en-us">

<?php
$game_name = (!isset($_REQUEST['game']) || empty(trim($_REQUEST['game'])) ? '' : $_REQUEST['game'] );

$height = isset($_REQUEST['h']) ? $_REQUEST['h'] : '100%';
if (!strpos($height, '%') && !strpos($height, 'px')) $height .= "px";

$path = get_option("wuss_webplayer_path");
if (empty($path))
	$path = "/BUILDS/";
if (is_ssl())
	$path = str_replace("http://", "https://", $path);

$img_src = $path . 'nogame.png';

if ($game_name == ''):
?>
<body style="margin:0px">
<center><div style="background-image: url('<?php echo $img_src; ?>');
            background-size: 100% 100%;
            border: none;
            min-height: 400px;">
    </div>
</center>
</body>
</html>
<?php
die();
endif;

$auto_start = isset($_REQUEST['autoload']) ? $_REQUEST['autoload'] : false;

$game_id    = isset($_REQUEST['gid']) ? intval($_REQUEST['gid']) : -1;
$img = $game_id > 0 ? wp_get_attachment_image_src(get_post_thumbnail_id($gid), 'original') : false;
if ($img) $img_src = $img[0];

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <script src="<?php echo $path . $game_name; ?>/Build/UnityLoader.js"></script>
    <script>
        function ShowGame(gamename)
        {
            if (gamename == '')
            {
                alert('No game specified');
                return;
            }
            UnityLoader.instantiate("gameContainer", gamename + "/Build/" + gamename + ".json");
        }
    </script>
</head>
<body style="margin:0px">
<div id="gameContainer" style="width: 100%; height: <?php echo $height; ?>;  margin: auto">
	<?php
	if (!$auto_start)
	{?>
        <center><a href="JavaScript:ShowGame('<?php echo $game_name; ?>')">
                <div id="wuss_game_placeholder" style="background-image: url('<?php echo $img_src; ?>'); background-size: 100% 100%; border: none; min-height: 400px;"></div></a>
        </center>
		<?php
	}
	?>
</div>
<?php
if ($auto_start)
{
	?>
    <script>ShowGame('<?php echo $game_name; ?>');</script>
	<?php
}
?></body>
</html>